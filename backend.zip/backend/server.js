const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const session = require('express-session');


// Create an instance of the Express application
const app = express();
const port = 3000;

// Enable CORS for all routes
app.use(cors());

// Middleware for parsing JSON
app.use(bodyParser.json());

// Set up storage for multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Ensure this folder exists
    },
    filename: (req, file, cb) => {
        const email = req.body.email.replace(/[^a-zA-Z0-9]/g, '_'); // Sanitize email to create a valid filename
        cb(null, `${email}${path.extname(file.originalname)}`); // Use sanitized email as filename
    }
});

const upload = multer({ storage: storage });

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // replace with your MySQL user
    password: 'Shaushwin01',  // replace with your MySQL password
    database: 'college_placement'  // your database name
});

// Connect to MySQL with error handling
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Route to fetch all students
app.get('/students', (req, res) => {
    const query = 'SELECT * FROM students';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// Route to handle student registration with file upload
app.post('/register/students', upload.single('resume'), (req, res) => {
    const { student_name, email, phone_number, department, year_of_study, password, security_question, security_answer } = req.body;

    // Check for required fields
    if (!student_name || !email || !password || !security_question || !security_answer) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Insert student data into the database
    const query = `
        INSERT INTO students (student_name, email, phone_number, department, year_of_study, password_hash, question, answer)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [student_name, email, phone_number, department, year_of_study, password, security_question, security_answer];

    db.query(query, values, (err, result) => {
        if (err) {
            if (err.code === 'ER_DUP_ENTRY') {
                return res.status(400).json({ error: 'Email already registered' });
            }
            return res.status(500).json({ error: err.message });
        }

        // Get the generated student_id
        const student_id = result.insertId;
        const username = student_name.replace(/\s+/g, '').toLowerCase(); // Using student_name as username, you can customize this logic

        // Insert the user into the users table
        const query1 = `
            INSERT INTO users (id, username, password, role)
            VALUES (?, ?, ?, 'student')
        `;
        const values1 = [student_id, username, password]; // Use student_id as the id for the user

        db.query(query1, values1, (err, result) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            // Respond with success
            res.status(201).json({ message: 'Student registered successfully', student_id });
        });
    });
});


// Route to fetch all admins
app.get('/admins', (req, res) => {
    const query = 'SELECT * FROM admins';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// Route to handle company registration
app.post('/register/companies', (req, res) => {
    const { company_name, contact, contact_email, password, industry_type, website } = req.body;

    // Check for required fields
    if (!company_name || !contact || !contact_email || !password) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if a company with the same contact_email already exists
    const checkQuery = 'SELECT * FROM companies WHERE contact_email = ?';
    db.query(checkQuery, [contact_email], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (results.length > 0) {
            return res.status(400).json({ error: 'Email already registered' });
        }

        // Insert company data into the database
        const query = `
            INSERT INTO companies (company_name, contact, contact_email, password, industry_type, website)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        const values = [company_name, contact, contact_email, password, industry_type, website];

        db.query(query, values, (err, result) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            // Get the generated company_id
            const company_id = result.insertId;
            const username = company_name.replace(/\s+/g, '').toLowerCase(); // Using company_name as username, can be customized

            // Insert the user into the users table
            const query1 = `
                INSERT INTO users (id, username, password, role)
                VALUES (?, ?, ?, 'company')
            `;
            const values1 = [company_id, username, password]; // Use company_id as the id for the user

            db.query(query1, values1, (err, result) => {
                if (err) {
                    return res.status(500).json({ error: err.message });
                }

                // Respond with success
                res.status(201).json({ message: 'Company registered successfully', company_id });
            });
        });
    });
});


// Login route without hashing
app.post('/login/students', (req, res) => {
    const { email, password } = req.body;

    // Query for finding the student by email
    const query = 'SELECT * FROM students WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        const student = results[0];
        // Directly compare the password (no hashing)
        if (password !== student.password_hash) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        // Send all the student details in the response
        res.json({ message: 'Login successful', student });
    });
});


app.post('/get-security-question', (req, res) => {
    const { email } = req.body;

    const query = 'SELECT question FROM students WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Email not registered' });

        res.json({ security_question: results[0].question });
    });
});

app.post('/reset-password', (req, res) => {
    const { email, securityAnswer, newPassword } = req.body;

    const query = 'SELECT answer FROM students WHERE email = ?';
    db.query(query, [email], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(404).json({ error: 'Email not registered' });

        const correctAnswer = results[0].answer;
        if (securityAnswer !== correctAnswer) {
            return res.status(400).json({ error: 'Incorrect answer' });
        }

        // Update password directly (no hashing)
        const updateQuery = 'UPDATE students SET password_hash = ? WHERE email = ?';
        db.query(updateQuery, [newPassword, email], (err) => {
            if (err) return res.status(500).json({ error: err.message });

            res.json({ message: 'Password reset successful' });
        });
    });
});
// Fetch job postings
app.get('/api/jobPostings', (req, res) => {
    const { student_id } = req.query; // Assuming student ID is passed as a query parameter

    if (!student_id) {
        return res.status(400).json({ message: 'Student ID is required' });
    }

    const query = `
        SELECT 
            jp.job_id, 
            jp.job_title, 
            jp.job_description, 
            jp.salary, 
            jp.location, 
            jp.application_deadline, 
            c.company_name
        FROM 
            job_postings jp
        JOIN 
            companies c 
        ON 
            jp.company_id = c.company_id
        WHERE 
            jp.job_id NOT IN (
                SELECT 
                    job_id 
                FROM 
                    applications 
                WHERE 
                    student_id = ?
            )
    `;

    db.query(query, [student_id], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching job postings', error: err });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No job postings available' });
        }
        res.json(results);
    });
});

// Fetch scheduled interviews
app.get('/api/interviews/:studentId', (req, res) => {
    const studentId = req.params.studentId;

    // Query to fetch interviews where the interview date is in the future or today
    const query = `
        SELECT 
    i.interview_id, 
    jp.job_title, 
    i.interview_date, 
    i.interview_time, 
    i.interview_mode, 
    i.interview_location, 
    c.company_name
FROM 
    interviews i
JOIN 
    applications a 
ON 
    i.application_id = a.application_id
JOIN 
    job_postings jp 
ON 
    a.job_id = jp.job_id
JOIN 
    companies c 
ON 
    jp.company_id = c.company_id
WHERE 
    i.student_id = 12  
    AND CONCAT(i.interview_date, ' ', i.interview_time) >= NOW(); -- Check both date and time`;

    db.query(query, [studentId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching interviews', error: err });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No upcoming interviews scheduled for this student' });
        }
        res.json(results);
    });
});

// Fetch job applications
app.get('/api/applications/:studentId', (req, res) => {
    const studentId = req.params.studentId;
    const query = `SELECT ja.application_id, 
       jp.job_title, 
       ja.application_status, 
       c.company_name
FROM applications ja 
JOIN job_postings jp ON ja.job_id = jp.job_id
JOIN companies c ON jp.company_id = c.company_id
WHERE ja.student_id = ?`;

    db.query(query, [studentId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching job applications', error: err });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No job applications found for this student' });
        }
        res.json(results);
    });
});

// Fetch job offers
app.get('/api/jobOffers/:studentId', (req, res) => {
    const studentId = req.params.studentId;
    const query = `SELECT jo.offer_id, jo.offer_date, jp.job_title, c.company_name, jp.salary
FROM job_offer jo
JOIN job_postings jp ON jo.job_id = jp.job_id
JOIN companies c ON jp.company_id = c.company_id
WHERE jo.student_id = ?`;

    db.query(query, [studentId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching job offers', error: err });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'No job offers available for this student' });
        }
        res.json(results);
    });
});

// Check if email is already registered
app.get('/api/check-email/:email', (req, res) => {
    const { email } = req.params;
    const query = 'SELECT * FROM students WHERE email = ?';

    db.query(query, [email], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Server error' });
        }
        if (result.length > 0) {
            return res.status(409).json({ message: 'Email already exists' });
        }
        return res.status(200).json({ message: 'Email is available' });
    });
});


// Update student details
app.put('/api/update-student/:student_id', (req, res) => {
    const { student_id } = req.params;
    const { student_name, phone_number, email } = req.body;

    // Check if the email already exists
    const checkEmailQuery = 'SELECT * FROM students WHERE email = ? AND student_id != ?';
    db.query(checkEmailQuery, [email, student_id], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Server error' });
        }

        // If email already exists for another student
        if (result.length > 0) {
            return res.status(409).json({ message: 'Email already exists' });
        }

        // Proceed with updating student details if no conflicts
        const query = 'UPDATE students SET student_name = ?, phone_number = ?, email = ? WHERE student_id = ?';
        db.query(query, [student_name, phone_number, email, student_id], (err, result) => {
            if (err) {
                return res.status(500).json({ message: 'Server error' });
            }
            if (result.affectedRows > 0) {
                return res.status(200).json({ message: 'Student updated successfully' });
            }
            return res.status(404).json({ message: 'Student not found or update failed' });
        });
    });
});


app.put('/api/update-academic-details/:student_id', (req, res) => {
    const { student_id } = req.params;
    const { department, year_of_study } = req.body; // Assuming academic details are department and year_of_study

    const query = 'UPDATE students SET department = ?, year_of_study = ? WHERE student_id = ?';
    db.query(query, [department, year_of_study, student_id], (err, result) => {
        if (err) {
            return res.status(500).json({ message: 'Server error' });
        }
        if (result.affectedRows > 0) {
            return res.status(200).json({ message: 'Academic details updated successfully' });
        }
        return res.status(404).json({ message: 'Student not found or update failed' });
    });
});

// Route to get job details by job_id
app.get('/api/jobPostings/:jobId', (req, res) => {
    const { jobId } = req.params;

    // SQL query to get job details based on jobId
    const query = 'SELECT * FROM job_postings WHERE job_id = ?';

    db.execute(query, [jobId], (err, result) => {
        if (err) {
            console.error('Error fetching job details:', err);
            return res.status(500).send('Failed to fetch job details');
        }

        if (result.length === 0) {
            return res.status(404).send('Job not found');
        }

        // Respond with job details
        res.status(200).json(result[0]);
    });
});
app.post('/login/companies', (req, res) => {
    const { email, password } = req.body;

    // Query for finding the company by email
    const query = 'SELECT * FROM companies WHERE contact_email = ?';
    db.query(query, [email], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        const company = results[0];
        // Directly compare the password (no hashing)
        if (password !== company.password) {
            return res.status(400).json({ error: 'Invalid email or password' });
        }

        res.json({ message: 'Login successful', company });
    });
});
// Route to submit an application
app.post('/api/applications', (req, res) => {
    const { student_id, job_id, application_status, resume_link, CGPA } = req.body;
    console.log('Incoming request body:', req.body); // Log incoming data

    if (!student_id || !job_id||!application_status || !resume_link || !CGPA) {
        return res.status(400).send('Missing required fields');
    }

    // Prepare the SQL query to insert data into the applications table
    const query = `
        INSERT INTO applications (student_id, job_id, resume_link, CGPA, application_status)
        VALUES (?, ?, ?, ?, ?)
    `;

    // Execute the query
    db.execute(query, [student_id, job_id, resume_link, CGPA, application_status], (err, result) => {
        if (err) {
            console.error('Error inserting application:', err);
            return res.status(500).send('Failed to submit application');
        }

        res.status(200).send('Application submitted successfully');
    });
});

// Fetch student details based on student_id
app.get('/api/students/:student_id', (req, res) => {
    const { student_id } = req.params;

    // Query the database for the student
    const query = 'SELECT * FROM students WHERE student_id = ?';
    db.query(query, [student_id], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ error: 'Student not found' });
        }

        const student = results[0];
        res.json(student); // Send student data in the response
    });
});

// Route to fetch jobs for a specific company
app.get('/jobs/:companyId', (req, res) => {
    const companyId = req.params.companyId;

    const query = 'SELECT * FROM job_postings WHERE company_id = ?';
    db.query(query, [companyId], (err, results) => {
        if (err) {
            console.error('Error fetching jobs: ', err);
            return res.status(500).json({ error: 'Error fetching jobs' });
        }
        res.json(results);
    });
});

// Route to post a job
app.post('/jobs', (req, res) => {
    const { job_title, job_description, salary, location, application_deadline, company_id } = req.body;

    const query = 'INSERT INTO job_postings (job_title, job_description, salary, location, application_deadline, company_id) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [job_title, job_description, salary, location, application_deadline, company_id], (err, result) => {
        if (err) {
            console.error('Error posting job: ', err);
            return res.status(500).json({ error: 'Error posting job' });
        }
        res.status(201).json({ message: 'Job posted successfully', jobId: result.insertId });
    });
});
// 3. Delete a job
app.delete('/jobs/:job_id', (req, res) => {
    const jobId = req.params.job_id;

    const query = 'DELETE FROM job_postings WHERE job_id = ?';
    db.query(query, [jobId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Error deleting job' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Job not found' });
        }
        res.json({ message: 'Job deleted successfully' });
    });
});

// 4. Update job details (salary and application deadline)
app.put('/jobs/:job_id', (req, res) => {
    const jobId = req.params.job_id;
    const { salary, application_deadline } = req.body;

    const query = 'UPDATE job_postings SET salary = ?, application_deadline = ? WHERE job_id = ?';
    db.query(query, [salary, application_deadline, jobId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Error updating job' });
        }
        if (results.affectedRows === 0) {
            return res.status(404).json({ error: 'Job not found' });
        }
        res.json({ message: 'Job updated successfully' });
    });
});

// Fetch applications for a company
// Fetch applications for a set of jobs
// Get applications by job ID
app.get('/applications/:jobId', (req, res) => {
    const jobId = req.params.jobId;  // Using req.params to get jobId
    const query = `SELECT applications.*, students.student_name
            FROM applications
JOIN students ON applications.student_id = students.student_id
WHERE applications.job_id = ?`;

    db.query(query, [jobId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Error fetching applications' });
        }
        res.json(results);
    });
});


app.get('/api/applications/interview/:jobId', (req, res) => {
    const jobId = req.params.jobId;
    const query = `
        SELECT applications.*, students.student_name
        FROM applications
        JOIN students ON applications.student_id = students.student_id
        LEFT JOIN interviews ON applications.application_id = interviews.application_id
        WHERE applications.job_id = ? 
        AND applications.application_status = 'interview_scheduled'
        AND interviews.application_id IS NULL
    `;
    db.query(query, [jobId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Error fetching applications' });
        }
        res.json(results);
    });
});


// Update application status
app.put('/applications/:applicationId', (req, res) => {
    const applicationId = req.params.applicationId;  // Using req.params to get applicationId
    const { application_status } = req.body;
    const query = 'UPDATE applications SET application_status = ? WHERE application_id = ?';
    db.query(query, [application_status, applicationId], (err, result) => {
        if (err) {
            return res.status(500).json({ error: 'Error updating application status' });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Application not found' });
        }
        res.json({ message: 'Application status updated successfully' });
    });
});

 app.post('/schedule-interview', (req, res) => {
    const {
        student_id,
        application_id,
        interview_date,
        interview_time,
        interview_mode,
        interview_location,
    } = req.body;

    console.log('Received schedule interview request:', req.body); // Debug log

    // Validate input fields
    if (!student_id || !application_id || !interview_date || !interview_time || !interview_mode || !interview_location) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    // Check if an interview already exists for this application_id
    const checkQuery = 'SELECT * FROM interviews WHERE application_id = ?';
    db.query(checkQuery, [application_id], (err, results) => {
        if (err) {
            console.error('Database error:', err); // Debug log
            return res.status(500).json({ error: 'Error checking existing interview', details: err });
        }

        if (results.length > 0) {
            return res.status(400).json({ error: 'Interview already scheduled for this application' });
        }

        // Insert new interview if none exists
        const query = `
            INSERT INTO interviews (student_id, application_id, interview_date, interview_time, interview_mode, interview_location)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        db.query(
            query,
            [student_id, application_id, interview_date, interview_time, interview_mode, interview_location],
            (err, result) => {
                if (err) {
                    console.error('Database error:', err); // Debug log
                    return res.status(500).json({ error: 'Error scheduling interview', details: err });
                }
                res.json({ message: 'Interview scheduled successfully', interview_id: result.insertId });
            }
        );
    });
});


app.get('/interviews', (req, res) => {
    const { application_id } = req.query;

    const query = 'SELECT * FROM interviews WHERE application_id = ?';
    db.query(query, [application_id], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Database query failed', details: err });
        }
        res.json(results);
    });
}); 

app.post('/interviews', (req, res) => {
    // Extract interview details from request body
    const { interview_date, interview_time, interview_mode, interview_location, student_id, application_id } = req.body;

    // Validation (optional)
    if (!interview_date || !interview_time || !interview_mode || !interview_location || !student_id || !application_id) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    // Construct the query for inserting interview details
    const query = `
        INSERT INTO interviews (student_id, application_id, interview_date, interview_time, interview_mode, interview_location)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    // Execute the query with values
    db.execute(query, [student_id, application_id, interview_date, interview_time, interview_mode, interview_location], (err, result) => {
        if (err) {
            console.error('Error scheduling interview:', err);
            return res.status(500).json({ message: 'Internal server error' });
        }

        // Respond with success
        res.status(201).json({
            message: 'Interview scheduled successfully!',
            interview_id: result.insertId, // Return the inserted interview's ID (optional)
        });
    });
});

app.get('/api/interviews/:jobId', (req, res) => {
    console.log("Job ID received:", req.params.jobId); // Log jobId
    const { jobId } = req.params;

    const query = `
        SELECT interviews.*, applications.student_id, applications.application_id, applications.application_status, students.student_name
           FROM interviews
           JOIN applications ON interviews.application_id = applications.application_id
          JOIN students ON applications.student_id = students.student_id
         WHERE applications.job_id=?
    `;
    db.query(query, [jobId], (err, results) => {
        if (err) {
            console.error("Error fetching interviews:", err);
            return res.status(500).json({ error: "Database error" });
        }
        console.log("Query Results:", results); // Log query results
        res.json(results);
    });
});

app.get('/api/jobs/:companyId', (req, res) => {
    const { companyId } = req.params;
    const query = `
        SELECT job_id, job_title
        FROM job_postings
        WHERE company_id = ?
    `;
    db.query(query, [companyId], (err, results) => {
        if (err) {
            console.error("Error fetching jobs:", err);
            return res.status(500).json({ error: "Database error" });
        }
        res.json(results);
    });
});
app.get('/api/job-application-counts', (req, res) => {
    const query = 'CALL GetAllJobApplicationCounts()';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching job details:', err);
            res.status(500).send('Server error');
        } else {
            res.json(results[0]);  // Send the results to the frontend
        }
    });
});
app.get('/api/applications-with-interviews', (req, res) => {
    // Assuming you have a SQL query here that joins the necessary tables.
    const query = `
        SELECT a.application_id, s.student_name, jp.job_title, a.application_status,
       i.interview_date, i.interview_time, i.interview_mode, i.interview_location, i.interview_status
FROM applications a
JOIN job_postings jp ON a.job_id = jp.job_id
JOIN students s ON a.student_id = s.student_id
LEFT JOIN interviews i ON a.application_id = i.application_id
LEFT JOIN job_offer jo ON a.job_id = jo.job_id AND a.student_id = jo.student_id
WHERE a.application_status = 'interview_scheduled'
  AND jo.offer_id IS NULL;

    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching applications with interviews:', err);
            res.status(500).send('Server error');
        } else {
            console.log("Results fetched:", results);  // Log the results for debugging
            res.json(results);
        }
    });
});

app.put('/api/update-interview-status/:applicationId', (req, res) => {
    const applicationId = req.params.applicationId;
    const { interview_status } = req.body; // The new interview status from the request body

    // Validate the status to be one of the allowed values
    if (!['Pass', 'Fail', 'Yet_to_be_completed'].includes(interview_status)) {
        return res.status(400).json({ message: "Invalid interview status" });
    }

    // SQL query to update the interview status for the given application
    const query = `
        UPDATE interviews
        SET interview_status = ?
        WHERE application_id = ?
    `;

    // Execute the query to update the interview status
    db.query(query, [interview_status, applicationId], (err, results) => {
        if (err) {
            console.error('Error updating interview status:', err);
            return res.status(500).send('Server error');
        }

        // If the update was successful, send a success response
        if (results.affectedRows > 0) {
            console.log(`Interview status for application ID ${applicationId} updated to ${interview_status}`);
            res.json({ message: 'Interview status updated successfully' });
        } else {
            console.log(`No matching application found with ID ${applicationId}`);
            res.status(404).json({ message: 'Application not found or status not updated' });
        }
    });
});

// Assuming you're using Express and a MySQL database connection (db)
app.get('/api/job-offers', (req, res) => {
    // The query provided to fetch job offers along with student and job details
    const query = `
        SELECT s.student_name, jp.job_title, jo.offer_id, jo.offer_date
        FROM job_offer jo
        JOIN students s ON jo.student_id = s.student_id
        JOIN job_postings jp ON jo.job_id = jp.job_id;
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching job offers:', err);
            res.status(500).send('Server error');
        } else {
            console.log("Job Offers fetched:", results);  // For debugging
            res.json(results);  // Send the result as a JSON response
        }
    });
});


// Admin Login Endpoint
app.post('/login/admin', (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
    }

    // Query the database for the admin
    const query = `SELECT * FROM admins WHERE email = ? AND password = ?`;

    db.query(query, [email, password], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(401).json({ error: 'Invalid email or password.' });
        }

        const admin = results[0];
        res.status(200).json({
            message: 'Login successful',
            admin: {
                admin_id: admin.admin_id,
                admin_name: admin.admin_name,
                email: admin.email,
            },
        });
    });
});

app.get('/api/admin/companies', (req, res) => {
    const query = 'SELECT company_id,company_name FROM companies';

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching companies', details: err });
        }
        res.json(results); // Send company details
    });
});

app.get('/api/admin/job-postings-stats', (req, res) => {
    const { companyId } = req.query;

    const query = `
        SELECT 
            jp.job_title,
            (SELECT COUNT(*) FROM applications a WHERE a.job_id = jp.job_id) AS num_applications,
            (SELECT COUNT(*) FROM interviews i WHERE i.application_id IN (SELECT application_id FROM applications WHERE job_id = jp.job_id)) AS num_interviews,
            (SELECT COUNT(*) FROM job_offer o WHERE o.job_id = jp.job_id) AS num_job_offers
        FROM job_postings jp
        WHERE jp.company_id = ? 
        AND jp.application_deadline >= CURRENT_DATE
        ORDER BY jp.posted_at DESC;
    `;

    db.query(query, [companyId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching job statistics', details: err });
        }
        res.json(results); // Send data as JSON
    });
});
// Fetching student details
app.get('/api/admin/students', (req, res) => {
    const query = `
        SELECT 
            student_id,
            student_name,
            email,
            phone_number,
            department,
            year_of_study
        FROM students
    `;

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching students', details: err });
        }
        res.json(results); // Send student details
    });
});

// Fetching student's recent application, upcoming interview, and number of job offers
app.get('/api/admin/student-job-stats', (req, res) => {
    const { studentId } = req.query;

    const query = `
        SELECT
    a.application_id,
    a.job_id,
    jp.job_title,
    c.company_name,                         -- Added company name
    a.applied_at AS application_date,       -- Corrected column name
    i.interview_date,
    (SELECT COUNT(*) 
     FROM job_offer o 
     WHERE o.student_id = a.student_id   -- Match on student_id
     AND o.job_id = a.job_id) AS num_job_offers  -- Match on job_id
FROM applications a
LEFT JOIN job_postings jp ON a.job_id = jp.job_id
LEFT JOIN companies c ON jp.company_id = c.company_id  -- Joining the companies table to get the company name
LEFT JOIN interviews i ON a.application_id = i.application_id
WHERE a.student_id = ?
AND (i.interview_date >= CURRENT_DATE OR i.interview_date IS NULL)  -- For upcoming interviews
ORDER BY a.applied_at DESC;


    `;

    db.query(query, [studentId], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching student job statistics', details: err });
        }
        res.json(results); // Send student's job-related data as JSON
    });
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
